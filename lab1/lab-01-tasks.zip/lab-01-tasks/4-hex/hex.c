#include<stdio.h>

int main()
{
    // TODO declare a char[] variable that stores the string

    // TODO print the char[] variable

    return 0;
}
